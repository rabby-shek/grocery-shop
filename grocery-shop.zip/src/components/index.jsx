export { default as Header } from './layouts/header/Header';
export { default as Footer } from './layouts/footer/Footer';
export { default as LoadScripts } from './LoadScripts';
export { default as HeroSection } from './hero-section/HeroSection';
export { default as FeaturedProducts } from './featured-products/FeaturedProducts';