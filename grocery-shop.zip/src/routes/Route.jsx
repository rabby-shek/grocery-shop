import { createBrowserRouter } from "react-router-dom";
import HomePage from "../pages/HomePage";
import ClientLayout from "../layouts/ClientLayout";
import CartPage from "../pages/CartPage";
const Route = createBrowserRouter([
  {
    path: "/",
    element: <ClientLayout />,
    children: [
      {
        index: true,
        element: <HomePage />,
      },
      {
        path: "cart",
        element: <CartPage />,
      }
    ],
  },
]);
export default Route;
