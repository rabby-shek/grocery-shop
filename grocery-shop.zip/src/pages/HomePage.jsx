import React from 'react'
import HeroSection from '../components/hero-section/HeroSection';
import FeaturedProducts from '../components/featured-products/FeaturedProducts';

const HomePage = () => {
  return (
    <>
     
      <HeroSection />
      <FeaturedProducts />
 
    </>
  )
}

export default HomePage;
